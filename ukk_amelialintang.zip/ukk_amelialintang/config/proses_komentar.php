<?php
session_start();
include '../config/koneksi.php';

// Mengambil data dari form
$fotoid = $_POST['fotoid'];
$userid = $_SESSION['userid'];
$isikomentar = $_POST['isikomentar'];
$tanggalkomentar = date('Y-m-d');

// Menyiapkan query untuk menyimpan komentar
$query = mysqli_prepare($koneksi, "INSERT INTO komentarfoto (fotoid, userid, isikomentar, tanggalkomentar) VALUES (?, ?, ?, ?)");

// Membind parameter ke prepared statement
mysqli_stmt_bind_param($query, "isss", $fotoid, $userid, $isikomentar, $tanggalkomentar);

// Mengeksekusi prepared statement
$result = mysqli_stmt_execute($query);

if ($result) {
    // Jika penyimpanan berhasil, redirect kembali ke halaman sebelumnya
    header("Location: {$_SERVER['HTTP_REFERER']}");
    exit();
} else {
    // Jika terjadi kesalahan, tampilkan pesan error
    echo "Error: " . mysqli_error($koneksi);
}

// Menutup prepared statement
mysqli_stmt_close($query);

// Menutup koneksi database
mysqli_close($koneksi);
