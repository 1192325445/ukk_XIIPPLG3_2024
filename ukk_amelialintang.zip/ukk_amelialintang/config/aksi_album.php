<?php
session_start();
include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = date('Y-m-d'); // Format tanggal harus 'Y-m-d' untuk MySQL
    $userid = $_SESSION['userid'];


    $sql = mysqli_query($koneksi, "INSERT INTO album VALUES('', '$namaalbum', '$deskripsi', '$tanggal', '$userid')");

    if ($sql) {
        echo "<script>
        alert('Data berhasil disimpan!!');
        location.href='../admin/album.php';
        </script>";
    } else {
        echo "<script>
        alert('Gagal menyimpan data: " . mysqli_error($koneksi) . "');
        location.href='../admin/album.php';
        </script>";
    }
}


if (isset($_POST['edit'])) {
    $albumid = $_POST['albumid'];
    $namaalbum = $_POST['namaalbum'];
    $deskripsi = $_POST['deskripsi'];
    $tanggaldibuat = date('Y-m-d'); // Format tanggal harus 'Y-m-d' untuk MySQL
    $userid = $_SESSION['userid'];

    $sql = mysqli_query($koneksi, "UPDATE album SET namaalbum='$namaalbum', deskripsi='$deskripsi', tanggaldibuat='$tanggaldibuat' WHERE albumid='$albumid'");

    if ($sql) {
        echo "<script>
            alert('Data berhasil diperbarui!!');
            location.href='../admin/album.php';
            </script>";
    } else {
        echo "<script>
            alert('Gagal memperbarui data: " . mysqli_error($koneksi) . "');
            location.href='../admin/album.php';
            </script>";
    }
}


if (isset($_POST['hapus'])) {
    $albumid = $_POST['albumid'];

    // Query untuk menghapus data album dari database
    $query = "DELETE FROM album WHERE albumid = '$albumid'";

    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil dihapus, arahkan kembali ke halaman album
        echo "<script>
        alert('Data album berhasil dihapus');
        window.location.href='../admin/album.php';
        </script>";
    } else {
        // Jika gagal dihapus, tampilkan pesan error
        echo "<script>
        alert('Gagal menghapus data album');
        window.location.href='../admin/album.php';
        </script>";
    }
}
